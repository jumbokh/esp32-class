msg1="Hello"
msg2="World"
print(msg1,msg2)
